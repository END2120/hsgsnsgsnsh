package com.example.modernhud;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class Config {
    private Config() {}

    public static final float MIN = 0.5f, MAX = 2.0f;

    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();
    public static final ModConfigSpec.DoubleValue SCALE =
            B.comment("HUD scale multiplier").defineInRange("hudScale", 1.0, MIN, MAX);
    public static final ModConfigSpec SPEC = B.build();

    public static float scale() {
        try {
            return SCALE.get().floatValue();
        } catch (Exception e) {
            return 1.0f; // config not loaded yet
        }
    }

    public static void setScale(double v) {
        v = Math.round(Math.max(MIN, Math.min(MAX, v)) * 20.0) / 20.0; // 5% steps
        try { SCALE.set(v); } catch (Exception ignored) {}
    }

    public static void save() {
        try { SCALE.save(); } catch (Exception ignored) {}
    }
}
