package com.example.modernhud;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.GameType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.common.NeoForge;

import java.util.Set;

@Mod(value = ModernHud.MODID, dist = Dist.CLIENT)
public class ModernHud {
    public static final String MODID = "modernhud";

    /** Vanilla layers that stay visible even when the HUD is hidden. */
    private static final Set<String> KEEP_WHEN_HIDDEN = Set.of("camera_overlays", "sleep_overlay", "debug_overlay");

    public ModernHud(IEventBus modBus, ModContainer container) {
        container.registerConfig(ModConfig.Type.CLIENT, Config.SPEC);
        container.registerExtensionPoint(IConfigScreenFactory.class, (c, parent) -> new HudConfigScreen(parent));
        modBus.addListener(this::registerLayers);
        modBus.addListener(this::registerKeys);
        NeoForge.EVENT_BUS.addListener(this::onLayerPre);
        NeoForge.EVENT_BUS.addListener(this::onTick);
    }

    private void registerKeys(RegisterKeyMappingsEvent e) {
        e.register(Keys.OPEN_CONFIG);
        e.register(Keys.TOGGLE_HOTBAR);
        e.register(Keys.TOGGLE_HUD);
    }

    private void registerLayers(RegisterGuiLayersEvent e) {
        // vignettes sit below the hotbar layer so the HUD draws on top of them
        e.registerBelow(VanillaGuiLayers.HOTBAR, ResourceLocation.fromNamespaceAndPath(MODID, "vignettes"), HudRenderer::renderVignettes);
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(MODID, "status"), HudRenderer::renderStatus);
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(MODID, "air"), HudRenderer::renderAir);
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(MODID, "xp"), HudRenderer::renderXp);
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(MODID, "hotbar"), HudRenderer::renderHotbar);
    }

    private void onTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        while (Keys.OPEN_CONFIG.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new HudConfigScreen(null));
        }
        while (Keys.TOGGLE_HOTBAR.consumeClick()) HudState.hotbarHidden = !HudState.hotbarHidden;
        while (Keys.TOGGLE_HUD.consumeClick()) HudState.hudHidden = !HudState.hudHidden;
    }

    /** Hide the vanilla elements we replace (and everything, when the HUD is toggled off). */
    private void onLayerPre(RenderGuiLayerEvent.Pre e) {
        ResourceLocation n = e.getName();
        if (HudState.hudHidden && n.getNamespace().equals("minecraft") && !KEEP_WHEN_HIDDEN.contains(n.getPath())) {
            e.setCanceled(true);
            return;
        }
        if (n.equals(VanillaGuiLayers.PLAYER_HEALTH) || n.equals(VanillaGuiLayers.FOOD_LEVEL)
                || n.equals(VanillaGuiLayers.ARMOR_LEVEL) || n.equals(VanillaGuiLayers.AIR_LEVEL)) {
            e.setCanceled(true);
        } else if (n.equals(VanillaGuiLayers.HOTBAR) || n.equals(VanillaGuiLayers.EXPERIENCE_BAR)
                || n.equals(VanillaGuiLayers.EXPERIENCE_LEVEL)) {
            var gm = Minecraft.getInstance().gameMode;
            boolean spectator = gm != null && gm.getPlayerMode() == GameType.SPECTATOR;
            if (!spectator || HudState.hotbarHidden) e.setCanceled(true);
        }
    }
}
