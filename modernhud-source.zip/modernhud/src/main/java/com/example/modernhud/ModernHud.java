package com.example.modernhud;

import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.GameType;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.common.NeoForge;

@Mod(value = ModernHud.MODID, dist = Dist.CLIENT)
public class ModernHud {
    public static final String MODID = "modernhud";

    public ModernHud(IEventBus modBus) {
        modBus.addListener(this::registerLayers);
        NeoForge.EVENT_BUS.addListener(this::onLayerPre);
    }

    private void registerLayers(RegisterGuiLayersEvent e) {
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(MODID, "status"), HudRenderer::renderStatus);
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(MODID, "air"), HudRenderer::renderAir);
        e.registerAboveAll(ResourceLocation.fromNamespaceAndPath(MODID, "hotbar"), HudRenderer::renderHotbar);
    }

    /** Hide the vanilla elements we replace. */
    private void onLayerPre(RenderGuiLayerEvent.Pre e) {
        ResourceLocation n = e.getName();
        if (n.equals(VanillaGuiLayers.PLAYER_HEALTH) || n.equals(VanillaGuiLayers.FOOD_LEVEL)
                || n.equals(VanillaGuiLayers.ARMOR_LEVEL) || n.equals(VanillaGuiLayers.AIR_LEVEL)) {
            e.setCanceled(true);
        } else if (n.equals(VanillaGuiLayers.HOTBAR) || n.equals(VanillaGuiLayers.EXPERIENCE_BAR)
                || n.equals(VanillaGuiLayers.EXPERIENCE_LEVEL)) {
            var gm = Minecraft.getInstance().gameMode;
            if (gm == null || gm.getPlayerMode() != GameType.SPECTATOR) e.setCanceled(true);
        }
    }
}
