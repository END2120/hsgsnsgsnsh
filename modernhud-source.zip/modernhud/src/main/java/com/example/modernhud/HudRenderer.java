package com.example.modernhud;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import org.joml.Matrix4f;

public final class HudRenderer {
    private HudRenderer() {}

    // Colors (ARGB)
    static final int HEALTH = 0xFFFFFFFF;   // #ffffff
    static final int FOOD   = 0xFFFFBB99;   // #ffbb99
    static final int ARMOR  = 0xFFBBFFEE;   // #bbffee
    static final int XP     = 0xFFBBFF99;
    static final int AIR_ON  = 0xFFFFFFFF;  // #ffffff
    static final int AIR_OFF = 0xFF443333;  // #443333
    static final int BORDER = 0x99000000;   // translucent black
    static final int TRACK  = 0x33000000;
    static final int PANEL  = 0x80000000;   // translucent black
    static final int SELECT = 0x80FFFFFF;   // translucent white

    static final float UI_SCALE = 0.8f;               // overall UI scale for bars / xp
    static final float HOTBAR_SCALE = 0.7f;
    static final int BAR_W = 72, BAR_H = 2;           // slim bars (in UI_SCALE units)
    static final int HOTBAR_OFFSET_X = 0;             // hotbar center, px right of screen center (0 = centered)
    static final float SMALL_ROW = 0.75f;             // food / armor rows are drawn at this fraction
    static final int HOTBAR_MARGIN_Y = 12;            // hotbar bottom margin
    static final int XP_W = 100;                      // xp bar width (UI_SCALE units)

    private static final String NS = ModernHud.MODID;
    private static final ResourceLocation ICON_HEART = ResourceLocation.fromNamespaceAndPath(NS, "textures/gui/heart.png");
    private static final ResourceLocation ICON_SHIELD = ResourceLocation.fromNamespaceAndPath(NS, "textures/gui/shield.png");
    private static final ResourceLocation ICON_STOMACH = ResourceLocation.fromNamespaceAndPath(NS, "textures/gui/stomach.png");

    private static boolean survival(Minecraft mc) {
        return mc.gameMode != null && mc.gameMode.canHurtPlayer() && mc.player != null;
    }

    // ---------- helpers ----------
    static void fillRound(GuiGraphics g, int x0, int y0, int x1, int y1, int r, int color) {
        r = Math.min(r, Math.min(x1 - x0, y1 - y0) / 2);
        g.fill(x0, y0 + r, x1, y1 - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
            g.fill(x0 + inset, y0 + i, x1 - inset, y0 + i + 1, color);
            g.fill(x0 + inset, y1 - i - 1, x1 - inset, y1 - i, color);
        }
    }

    /** Smooth arc band drawn with real geometry (no pixel dots). lit < 0 means all segments use onC. */
    private static void arcBand(GuiGraphics g, double cx, double cy, double r0, double r1,
                                double aStart, double aEnd, int segs, int lit, int onC, int offC) {
        Matrix4f m = g.pose().last().pose();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        BufferBuilder b = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i < segs; i++) {
            double a0 = aStart + (aEnd - aStart) * i / segs;
            double a1 = aStart + (aEnd - aStart) * (i + 1) / segs;
            int c = (lit < 0 || i < lit) ? onC : offC;
            b.addVertex(m, (float) (cx + r0 * Math.cos(a0)), (float) (cy + r0 * Math.sin(a0)), 0f).setColor(c);
            b.addVertex(m, (float) (cx + r1 * Math.cos(a0)), (float) (cy + r1 * Math.sin(a0)), 0f).setColor(c);
            b.addVertex(m, (float) (cx + r1 * Math.cos(a1)), (float) (cy + r1 * Math.sin(a1)), 0f).setColor(c);
            b.addVertex(m, (float) (cx + r0 * Math.cos(a1)), (float) (cy + r0 * Math.sin(a1)), 0f).setColor(c);
        }
        BufferUploader.drawWithShader(b.buildOrThrow());
        RenderSystem.enableCull();
    }

    private static void icon(GuiGraphics g, ResourceLocation tex, int x, int y, int size, int argb) {
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, 1f);
        g.blit(tex, x, y, size, size, 0, 0, 32, 32, 32, 32);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    // ---------- health / food / armor ----------
    public static void renderStatus(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (!survival(mc)) return;
        LocalPlayer p = mc.player;
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.scale(UI_SCALE, UI_SCALE, 1f);
        int baseY = Math.round(g.guiHeight() / UI_SCALE) - 14;

        float hp = p.getHealth();
        String hpText = String.valueOf((int) Math.ceil(hp));
        if (p.getAbsorptionAmount() > 0) hpText += "+" + (int) Math.ceil(p.getAbsorptionAmount());

        row(g, mc.font, baseY, 1f, ICON_HEART, HEALTH, hp / Math.max(1f, p.getMaxHealth()), hpText);
        int food = p.getFoodData().getFoodLevel();
        row(g, mc.font, baseY - 11, SMALL_ROW, ICON_STOMACH, FOOD, food / 20f, String.valueOf(food));
        int armor = p.getArmorValue();
        row(g, mc.font, baseY - 20, SMALL_ROW, ICON_SHIELD, ARMOR, armor / 20f, String.valueOf(armor));
        ps.popPose();
    }

    private static void row(GuiGraphics g, Font font, int y, float sc, ResourceLocation ic, int color,
                            float frac, String text) {
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(10, y, 0);
        ps.scale(sc, sc, 1f);
        icon(g, ic, 0, 0, 9, color);
        int bx = 14, by = 4;
        g.fill(bx - 1, by - 1, bx + BAR_W + 1, by + BAR_H + 1, BORDER);
        g.fill(bx, by, bx + BAR_W, by + BAR_H, 0xFF1A1A1A);
        g.fill(bx, by, bx + BAR_W, by + BAR_H, TRACK);
        int w = Math.round(BAR_W * Mth.clamp(frac, 0f, 1f));
        if (w > 0) g.fill(bx, by, bx + w, by + BAR_H, color);
        g.drawString(font, text, bx + BAR_W + 6, 1, 0xFFFFFFFF, false);
        ps.popPose();
    }

    // ---------- curved air bar (right of crosshair) ----------
    public static void renderAir(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (!survival(mc)) return;
        LocalPlayer p = mc.player;
        int max = p.getMaxAirSupply();
        int air = Mth.clamp(p.getAirSupply(), 0, max);
        if (air >= max && !p.isEyeInFluid(FluidTags.WATER)) return;

        double cx = g.guiWidth() / 2.0, cy = g.guiHeight() / 2.0;
        double a0 = Math.toRadians(-50), a1 = Math.toRadians(50);
        int segs = 64;
        int lit = (int) Math.ceil(segs * (air / (double) max));
        // translucent black outline, then the bar
        arcBand(g, cx, cy, 21.4, 23.0, Math.toRadians(-51), Math.toRadians(51), segs, -1, BORDER, BORDER);
        arcBand(g, cx, cy, 21.9, 22.5, a0, a1, segs, lit, AIR_ON, AIR_OFF);
    }

    // ---------- hotbar (compact, bottom center-right) + xp bar (bottom center) ----------
    public static void renderHotbar(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.gameMode == null || mc.gameMode.getPlayerMode() == GameType.SPECTATOR) return;
        LocalPlayer p = mc.player;
        PoseStack ps = g.pose();

        // --- xp bar at bottom center ---
        ps.pushPose();
        ps.scale(UI_SCALE, UI_SCALE, 1f);
        int vw = Math.round(g.guiWidth() / UI_SCALE), vh = Math.round(g.guiHeight() / UI_SCALE);
        int ex = vw / 2 - XP_W / 2, ey = vh - 8;
        g.fill(ex - 1, ey - 1, ex + XP_W + 1, ey + 3, BORDER);
        g.fill(ex, ey, ex + XP_W, ey + 2, TRACK);
        int xw = Math.round(XP_W * Mth.clamp(p.experienceProgress, 0f, 1f));
        if (xw > 0) g.fill(ex, ey, ex + xw, ey + 2, XP);
        if (p.experienceLevel > 0) {
            String lv = String.valueOf(p.experienceLevel);
            g.drawString(mc.font, lv, ex + XP_W + 5, ey - 3, XP, false);
        }
        ps.popPose();

        // --- hotbar ---
        final float s = HOTBAR_SCALE;
        final int cell = 20, panelW = 9 * cell + 4, panelH = 24;
        int x0 = Math.round(g.guiWidth() / 2f + HOTBAR_OFFSET_X - panelW * s / 2f);
        int y0 = Math.round(g.guiHeight() - panelH * s - HOTBAR_MARGIN_Y);

        ps.pushPose();
        ps.translate(x0, y0, 0);
        ps.scale(s, s, 1f);

        fillRound(g, 0, 0, panelW, panelH, 4, PANEL);
        int sel = p.getInventory().selected;
        // selected slot: slightly larger frame, translucent white
        fillRound(g, 2 + sel * cell - 1, 0, 2 + sel * cell + 21, panelH, 4, SELECT);
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().items.get(i);
            int ix = 2 + i * cell + 1, iy = 4;
            if (!st.isEmpty()) {
                g.renderItem(st, ix, iy);
                g.renderItemDecorations(mc.font, st, ix, iy);
            }
        }
        ItemStack off = p.getOffhandItem();
        if (!off.isEmpty()) {
            fillRound(g, panelW + 3, 0, panelW + 29, panelH, 4, PANEL);
            g.renderItem(off, panelW + 8, 4);
            g.renderItemDecorations(mc.font, off, panelW + 8, 4);
        }
        ps.popPose();
    }
}
