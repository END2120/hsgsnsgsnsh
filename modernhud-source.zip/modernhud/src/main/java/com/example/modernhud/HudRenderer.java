package com.example.modernhud;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import org.joml.Matrix4f;

public final class HudRenderer {
    private HudRenderer() {}

    // Colors (ARGB)
    static final int HEALTH = 0xFFFFFFFF;   // #ffffff
    static final int FOOD   = 0xFFFFBB99;   // #ffbb99
    static final int ARMOR  = 0xFFBBFFEE;   // #bbffee
    static final int XP     = 0xFFBBFF99;
    static final int AIR_ON  = 0xFFFFFFFF;  // full oxygen: #ffffff
    static final int AIR_LOW = 0xFFFF4D4D;  // almost no oxygen: red
    static final int AIR_OFF = 0xFF443333;  // #443333
    static final int BORDER = 0x99000000;   // translucent black
    static final int TRACK  = 0x33000000;
    static final int PANEL  = 0x80000000;   // translucent black
    static final int SELECT = 0x80FFFFFF;   // translucent white

    static final float UI_SCALE = 1.0f;               // base scale for bars / xp (multiplied by the config slider)
    static final float HOTBAR_SCALE = 0.85f;          // base scale for the hotbar
    static final float SMALL_ROW = 0.75f;             // food / armor rows are drawn at this fraction
    static final int BAR_W = 72, BAR_H = 2;
    static final int XP_W = 100;
    static final int HOTBAR_OFFSET_X = 0;             // hotbar center, px right of screen center (0 = centered)

    private static final String NS = ModernHud.MODID;
    private static final ResourceLocation ICON_HEART = ResourceLocation.fromNamespaceAndPath(NS, "textures/gui/heart.png");
    private static final ResourceLocation ICON_SHIELD = ResourceLocation.fromNamespaceAndPath(NS, "textures/gui/shield.png");
    private static final ResourceLocation ICON_STOMACH = ResourceLocation.fromNamespaceAndPath(NS, "textures/gui/stomach.png");

    private static float k() { return UI_SCALE * Config.scale(); }
    private static float hs() { return HOTBAR_SCALE * Config.scale(); }

    private static boolean survival(Minecraft mc) {
        return mc.gameMode != null && mc.gameMode.canHurtPlayer() && mc.player != null;
    }

    // ---------- helpers ----------
    private static int argb(float r, float g, float b, float a) {
        return (Mth.clamp(Math.round(a * 255f), 0, 255) << 24) | (Mth.clamp(Math.round(r * 255f), 0, 255) << 16)
                | (Mth.clamp(Math.round(g * 255f), 0, 255) << 8) | Mth.clamp(Math.round(b * 255f), 0, 255);
    }

    /** Smooth rounded rectangle: real arcs plus a feathered fringe for anti-aliased edges. */
    static void roundRect(GuiGraphics g, float x0, float y0, float x1, float y1, float r, float feather, int color) {
        final int SEG = 10;
        Matrix4f m = g.pose().last().pose();
        float[][] corners = {{x1 - r, y0 + r, -90f}, {x1 - r, y1 - r, 0f}, {x0 + r, y1 - r, 90f}, {x0 + r, y0 + r, 180f}};
        int n = 4 * (SEG + 1);
        float[] px = new float[n], py = new float[n], qx = new float[n], qy = new float[n];
        int idx = 0;
        for (float[] c : corners) {
            for (int k = 0; k <= SEG; k++) {
                double ang = Math.toRadians(c[2] + 90.0 * k / SEG);
                float cs = (float) Math.cos(ang), sn = (float) Math.sin(ang);
                px[idx] = c[0] + r * cs;             py[idx] = c[1] + r * sn;
                qx[idx] = c[0] + (r + feather) * cs; qy[idx] = c[1] + (r + feather) * sn;
                idx++;
            }
        }
        int clear = color & 0x00FFFFFF;
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        BufferBuilder fan = Tesselator.getInstance().begin(VertexFormat.Mode.TRIANGLE_FAN, DefaultVertexFormat.POSITION_COLOR);
        fan.addVertex(m, (x0 + x1) / 2f, (y0 + y1) / 2f, 0f).setColor(color);
        for (int i = 0; i <= n; i++) fan.addVertex(m, px[i % n], py[i % n], 0f).setColor(color);
        BufferUploader.drawWithShader(fan.buildOrThrow());
        BufferBuilder ring = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            ring.addVertex(m, px[i], py[i], 0f).setColor(color);
            ring.addVertex(m, qx[i], qy[i], 0f).setColor(clear);
            ring.addVertex(m, qx[j], qy[j], 0f).setColor(clear);
            ring.addVertex(m, px[j], py[j], 0f).setColor(color);
        }
        BufferUploader.drawWithShader(ring.buildOrThrow());
        RenderSystem.enableCull();
    }

    private static int lerpColor(int a, int b, float t) {
        t = Mth.clamp(t, 0f, 1f);
        int r = Math.round(Mth.lerp(t, (a >> 16) & 255, (b >> 16) & 255));
        int gr = Math.round(Mth.lerp(t, (a >> 8) & 255, (b >> 8) & 255));
        int bl = Math.round(Mth.lerp(t, a & 255, b & 255));
        return 0xFF000000 | (r << 16) | (gr << 8) | bl;
    }

    /** Smooth arc band drawn with real geometry. Segments with index >= litFrom use onC, the rest offC. */
    private static void arcBand(GuiGraphics g, double cx, double cy, double r0, double r1,
                                double aStart, double aEnd, int segs, int litFrom, int onC, int offC) {
        Matrix4f m = g.pose().last().pose();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        BufferBuilder b = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i < segs; i++) {
            double a0 = aStart + (aEnd - aStart) * i / segs;
            double a1 = aStart + (aEnd - aStart) * (i + 1) / segs;
            int c = i >= litFrom ? onC : offC;
            b.addVertex(m, (float) (cx + r0 * Math.cos(a0)), (float) (cy + r0 * Math.sin(a0)), 0f).setColor(c);
            b.addVertex(m, (float) (cx + r1 * Math.cos(a0)), (float) (cy + r1 * Math.sin(a0)), 0f).setColor(c);
            b.addVertex(m, (float) (cx + r1 * Math.cos(a1)), (float) (cy + r1 * Math.sin(a1)), 0f).setColor(c);
            b.addVertex(m, (float) (cx + r0 * Math.cos(a1)), (float) (cy + r0 * Math.sin(a1)), 0f).setColor(c);
        }
        BufferUploader.drawWithShader(b.buildOrThrow());
        RenderSystem.enableCull();
    }

    private static void icon(GuiGraphics g, ResourceLocation tex, int x, int y, int size, int argb) {
        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(((argb >> 16) & 255) / 255f, ((argb >> 8) & 255) / 255f, (argb & 255) / 255f, 1f);
        g.blit(tex, x, y, size, size, 0, 0, 32, 32, 32, 32);
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
    }

    // ---------- vignettes (oxygen / low health / hunger) ----------
    private static float vOxygen, vHealth, vHunger;

    /** Elliptical vignette from concentric rings with a smoothstep alpha profile (no texture, no visible edge). */
    private static void vignette(GuiGraphics g, float r, float gr, float b, float a) {
        if (a <= 0.004f) return;
        Matrix4f m = g.pose().last().pose();
        float cx = g.guiWidth() / 2f, cy = g.guiHeight() / 2f;
        final int N = 72, J = 28;
        final float rIn = 0.45f, rOut = 1.5f;
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        BufferBuilder buf = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        for (int j = 0; j < J; j++) {
            float u0 = j / (float) J, u1 = (j + 1) / (float) J;
            float r0 = Mth.lerp(u0, rIn, rOut), r1 = Mth.lerp(u1, rIn, rOut);
            int c0 = argb(r, gr, b, a * u0 * u0 * (3f - 2f * u0));
            int c1 = argb(r, gr, b, a * u1 * u1 * (3f - 2f * u1));
            for (int i = 0; i < N; i++) {
                double t0 = 2 * Math.PI * i / N, t1 = 2 * Math.PI * (i + 1) / N;
                float ca = (float) Math.cos(t0), sa = (float) Math.sin(t0);
                float cb = (float) Math.cos(t1), sb = (float) Math.sin(t1);
                buf.addVertex(m, cx + r0 * cx * ca, cy + r0 * cy * sa, 0f).setColor(c0);
                buf.addVertex(m, cx + r1 * cx * ca, cy + r1 * cy * sa, 0f).setColor(c1);
                buf.addVertex(m, cx + r1 * cx * cb, cy + r1 * cy * sb, 0f).setColor(c1);
                buf.addVertex(m, cx + r0 * cx * cb, cy + r0 * cy * sb, 0f).setColor(c0);
            }
        }
        BufferUploader.drawWithShader(buf.buildOrThrow());
        RenderSystem.enableCull();
    }

    public static void renderVignettes(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        float tOx = 0, tHp = 0, tFood = 0;
        if (survival(mc) && !HudState.hudHidden) {
            LocalPlayer p = mc.player;
            int max = p.getMaxAirSupply();
            float airFrac = Mth.clamp(p.getAirSupply(), 0, max) / (float) max;
            tOx = Mth.clamp((0.6f - airFrac) / 0.6f, 0f, 1f) * 0.65f;       // fades in below 60% oxygen
            float hp = p.getHealth();
            if (hp <= 6f) tHp = Mth.clamp((7f - hp) / 7f, 0f, 1f) * 0.7f;    // gradually stronger at 6 or less
            int food = p.getFoodData().getFoodLevel();
            if (food <= 5) tFood = Mth.clamp((6f - food) / 6f, 0f, 1f) * 0.45f; // light black at 5 or less
        }
        // ease toward the target so it fades in/out gradually
        vOxygen += (tOx - vOxygen) * 0.06f;
        vHealth += (tHp - vHealth) * 0.06f;
        vHunger += (tFood - vHunger) * 0.06f;

        vignette(g, 0f, 0f, 0f, vHunger);
        vignette(g, 0.45f, 0.05f, 0.75f, vOxygen);
        vignette(g, 0.8f, 0f, 0f, vHealth);
    }

    // ---------- health / food / armor ----------
    public static void renderStatus(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (HudState.hudHidden || !survival(mc)) return;
        LocalPlayer p = mc.player;
        float k = k();
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.scale(k, k, 1f);
        int baseY = Math.round(g.guiHeight() / k) - 14;

        float hp = p.getHealth();
        String hpText = String.valueOf((int) Math.ceil(hp));
        if (p.getAbsorptionAmount() > 0) hpText += "+" + (int) Math.ceil(p.getAbsorptionAmount());

        row(g, mc.font, baseY, 1f, ICON_HEART, HEALTH, hp / Math.max(1f, p.getMaxHealth()), hpText);
        int food = p.getFoodData().getFoodLevel();
        row(g, mc.font, baseY - 11, SMALL_ROW, ICON_STOMACH, FOOD, food / 20f, String.valueOf(food));
        int armor = p.getArmorValue();
        row(g, mc.font, baseY - 20, SMALL_ROW, ICON_SHIELD, ARMOR, armor / 20f, String.valueOf(armor));
        ps.popPose();
    }

    private static void row(GuiGraphics g, Font font, int y, float sc, ResourceLocation ic, int color,
                            float frac, String text) {
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(10, y, 0);
        ps.scale(sc, sc, 1f);
        icon(g, ic, 0, 0, 9, color);
        int bx = 14, by = 4;
        g.fill(bx - 1, by - 1, bx + BAR_W + 1, by + BAR_H + 1, BORDER);
        g.fill(bx, by, bx + BAR_W, by + BAR_H, 0xFF1A1A1A);
        g.fill(bx, by, bx + BAR_W, by + BAR_H, TRACK);
        int w = Math.round(BAR_W * Mth.clamp(frac, 0f, 1f));
        if (w > 0) g.fill(bx, by, bx + w, by + BAR_H, color);
        g.drawString(font, text, bx + BAR_W + 6, 1, 0xFFFFFFFF, false);
        ps.popPose();
    }

    // ---------- curved air bar (right of crosshair) ----------
    public static void renderAir(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (HudState.hudHidden || !survival(mc)) return;
        LocalPlayer p = mc.player;
        int max = p.getMaxAirSupply();
        int air = Mth.clamp(p.getAirSupply(), 0, max);
        if (air >= max && !p.isEyeInFluid(FluidTags.WATER)) return;

        double m = Config.scale();
        double cx = g.guiWidth() / 2.0, cy = g.guiHeight() / 2.0;
        double a0 = Math.toRadians(-50), a1 = Math.toRadians(50);
        int segs = 64;
        float frac = air / (float) max;
        int lit = (int) Math.ceil(segs * frac);
        int litFrom = segs - lit;                       // lit part stays at the bottom: it shrinks from the top
        int onC = lerpColor(AIR_LOW, AIR_ON, frac);     // white -> red as oxygen runs out
        // translucent black outline, then the bar
        arcBand(g, cx, cy, 24.9 * m, 27.1 * m, Math.toRadians(-51), Math.toRadians(51), segs, 0, BORDER, BORDER);
        arcBand(g, cx, cy, 25.4 * m, 26.6 * m, a0, a1, segs, litFrom, onC, AIR_OFF);
        // remaining air in percent, right of the gauge
        String txt = Math.round(frac * 100f) + "%";
        PoseStack aps = g.pose();
        aps.pushPose();
        aps.translate(cx + 27.1 * m + 5 * m, cy - 4 * m, 0);
        aps.scale((float) m, (float) m, 1f);
        g.drawString(mc.font, txt, 0, 0, onC, false);
        aps.popPose();
    }

    // ---------- xp bar (bottom center) ----------
    public static void renderXp(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (HudState.hudHidden || HudState.hotbarHidden) return;
        if (mc.player == null || mc.gameMode == null || !mc.gameMode.hasExperience()) return;
        LocalPlayer p = mc.player;
        float k = k();
        PoseStack ps = g.pose();
        ps.pushPose();
        ps.scale(k, k, 1f);
        int vw = Math.round(g.guiWidth() / k), vh = Math.round(g.guiHeight() / k);
        int ex = vw / 2 - XP_W / 2, ey = vh - 8;
        g.fill(ex - 1, ey - 1, ex + XP_W + 1, ey + 3, BORDER);
        g.fill(ex, ey, ex + XP_W, ey + 2, TRACK);
        int xw = Math.round(XP_W * Mth.clamp(p.experienceProgress, 0f, 1f));
        if (xw > 0) g.fill(ex, ey, ex + xw, ey + 2, XP);
        if (p.experienceLevel > 0) {
            g.drawString(mc.font, String.valueOf(p.experienceLevel), ex + XP_W + 5, ey - 3, XP, false);
        }
        ps.popPose();
    }

    // ---------- hotbar (bottom center) + durability (right side) ----------
    public static void renderHotbar(GuiGraphics g, DeltaTracker dt) {
        Minecraft mc = Minecraft.getInstance();
        if (HudState.hudHidden || HudState.hotbarHidden) return;
        if (mc.player == null || mc.gameMode == null || mc.gameMode.getPlayerMode() == GameType.SPECTATOR) return;
        LocalPlayer p = mc.player;

        final float s = hs();
        final int cell = 20, panelW = 9 * cell + 4, panelH = 24;
        int bottomMargin = Math.round(14 * k());
        int x0 = Math.round(g.guiWidth() / 2f + HOTBAR_OFFSET_X - panelW * s / 2f);
        int y0 = Math.round(g.guiHeight() - panelH * s - bottomMargin);

        PoseStack ps = g.pose();
        ps.pushPose();
        ps.translate(x0, y0, 0);
        ps.scale(s, s, 1f);

        float fth = (float) (1.0 / (s * mc.getWindow().getGuiScale()));
        roundRect(g, 0, 0, panelW, panelH, 4, fth, PANEL);
        int sel = p.getInventory().selected;
        // selected slot: slightly larger frame, translucent white
        roundRect(g, 2 + sel * cell - 1, 0, 2 + sel * cell + 21, panelH, 4, fth, SELECT);
        for (int i = 0; i < 9; i++) {
            ItemStack st = p.getInventory().items.get(i);
            int ix = 2 + i * cell + 1, iy = 4;
            if (!st.isEmpty()) {
                g.renderItem(st, ix, iy);
                g.renderItemDecorations(mc.font, st, ix, iy);
            }
        }
        // off-hand on the left
        ItemStack off = p.getOffhandItem();
        if (!off.isEmpty()) {
            roundRect(g, -29, 0, -3, panelH, 4, fth, PANEL);
            g.renderItem(off, -24, 4);
            g.renderItemDecorations(mc.font, off, -24, 4);
        }
        // durability of the selected item: number on top, bar below, to the right of the hotbar
        ItemStack held = p.getMainHandItem();
        if (held.isDamageableItem()) {
            int maxD = held.getMaxDamage();
            int left = Math.max(0, maxD - held.getDamageValue());
            String txt = left + "/" + maxD;
            int bw = Math.max(mc.font.width(txt), 40);
            int dx = panelW + 8, by = 15;
            g.drawString(mc.font, txt, dx, 3, 0xFFFFFFFF, false);
            g.fill(dx - 1, by - 1, dx + bw + 1, by + 4, BORDER);
            g.fill(dx, by, dx + bw, by + 3, TRACK);
            int dw = Math.round(bw * Mth.clamp(left / (float) Math.max(1, maxD), 0f, 1f));
            if (dw > 0) g.fill(dx, by, dx + dw, by + 3, 0xFF000000 | held.getBarColor());
        }
        ps.popPose();
    }
}
