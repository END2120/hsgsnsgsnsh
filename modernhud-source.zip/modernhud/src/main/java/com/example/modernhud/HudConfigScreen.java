package com.example.modernhud;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

public class HudConfigScreen extends Screen {
    private final Screen parent;

    public HudConfigScreen(Screen parent) {
        super(Component.translatable("modernhud.config.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx = this.width / 2, cy = this.height / 2;
        addRenderableWidget(new ScaleSlider(cx - 100, cy - 10, 200, 20));
        addRenderableWidget(Button.builder(Component.translatable("modernhud.config.reset"), b -> {
            Config.setScale(1.0);
            rebuildWidgets();
        }).bounds(cx - 100, cy + 16, 98, 20).build());
        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(cx + 2, cy + 16, 98, 20).build());
    }

    /** Keep the game (and the HUD) visible behind the screen so the slider shows a live preview. */
    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {}

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);
        g.drawCenteredString(this.font, this.title, this.width / 2, this.height / 2 - 30, 0xFFFFFFFF);
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void onClose() {
        Config.save();
        this.minecraft.setScreen(parent);
    }

    private static final class ScaleSlider extends AbstractSliderButton {
        ScaleSlider(int x, int y, int w, int h) {
            super(x, y, w, h, Component.empty(), (Config.scale() - Config.MIN) / (Config.MAX - Config.MIN));
            updateMessage();
        }

        private double current() { return Config.MIN + this.value * (Config.MAX - Config.MIN); }

        @Override
        protected void updateMessage() {
            setMessage(Component.translatable("modernhud.config.scale",
                    Math.round(Math.round(current() * 20.0) / 20.0 * 100) + "%"));
        }

        @Override
        protected void applyValue() { Config.setScale(current()); }
    }
}
