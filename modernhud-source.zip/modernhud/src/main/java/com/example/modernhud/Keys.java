package com.example.modernhud;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public final class Keys {
    private Keys() {}
    public static final String CATEGORY = "key.categories.modernhud";

    public static final KeyMapping OPEN_CONFIG = new KeyMapping("key.modernhud.open_config",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O, CATEGORY);
    public static final KeyMapping TOGGLE_HOTBAR = new KeyMapping("key.modernhud.toggle_hotbar",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, CATEGORY);
    public static final KeyMapping TOGGLE_HUD = new KeyMapping("key.modernhud.toggle_hud",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CATEGORY);
}
