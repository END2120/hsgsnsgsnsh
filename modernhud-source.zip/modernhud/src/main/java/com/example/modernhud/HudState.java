package com.example.modernhud;

/** Runtime toggles (not persisted). */
public final class HudState {
    private HudState() {}
    public static boolean hudHidden = false;
    public static boolean hotbarHidden = false;
}
