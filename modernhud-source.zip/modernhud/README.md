# Modern HUD (NeoForge 1.21.1)

## ビルド
1. JDK 21 と Gradle 8.x を用意
2. このフォルダで `gradle wrapper --gradle-version 8.10.2` を実行(初回のみ)
3. `./gradlew build`
4. `build/libs/modernhud-1.0.0.jar` を `mods` フォルダへ

## 構成
- 体力(#ffffff)/満腹度(#ffbb99)/防御力(#bbffee): 左下、細長いバー、半透明黒の枠線
- 酸素: クロスヘア右の曲線バー(残り #ffffff / 減少分 #443333)
- ホットバー: 右下、やや小さく、背景は半透明黒。選択中は少し大きく半透明白
